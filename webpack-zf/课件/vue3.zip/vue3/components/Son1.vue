<template>
   <div>
       son1：
       <!-- {{m}}{{arr}} -->
       {{$attrs}}
       <!-- {{value}} -->
       <button @click="$listeners.click()">更改钱</button>
       <GrandSon1 v-bind="$attrs" :name="$attrs.name" v-on="$listeners" ref="grandSon"></GrandSon1>
   </div> 
</template>
<script>
import GrandSon1 from './GrandSon1';
//v-on:   $emit 
//订阅发布模式 父组件监听子组件的事件 ,当子组件执行监听事件时，父组件执行事件绑定的方法

export default {
    // props:{
    //     m:{
    //         type:[String,Number],
    //         default:200,
    //         // required:true,
    //         validator:(val)=>{ //自定义的规则
    //              return val>200&&val<1500   
    //         }
    //     },
    //     arr:{
    //         type:Array,
    //         default:()=>[1]   //数组或对象值是函数
    //     },
    //     obj:{
    //         type:Object,
    //         default:()=>({}) 
    //     }
    // },
    props:{
        value:Number
    },
    methods:{
        fn(){
            // this.$emit('changeM',500);
            //this.$emit('update:m',500);语法糖
              this.$emit('input',500)  
        }
    },
    components:{
        GrandSon1
    },
    mounted(){
        // this.$parent.fn1(); 
        // this.$children[0].fn()
        // this.$refs.grandSon.fn();  ref 拿到DOM元素和组件实例
    }
}
</script>