<template>
    <div >
        <!--  父组件监听子组件事件changM,并且事件绑定方法fn -->
        parent:
        <!-- <Son1 :m="money" @changeM="fn"></Son1> -->
        <!-- <Son1 :m.sync ="money"></Son1>  语法糖的写法 -->
        <!-- 传给自组件的数据是放在value属性里,监听的事件是input -->
        <!-- <Son1 v-model="money" ></Son1>  -->
        <Son1 name="zf" age=10  @click="fn1"></Son1>

    </div>
    
</template>
<script>
import Son1 from './Son1';
export default {
    provide(){
        return {
            parentMsg:"parent"
        }
    },
    data(){
        return {
            money:400
        }
    },
    methods:{
        fn(data){ //data指子组件传递过来的数据
            this.money = data;
        },
        fn1(){
            alert(1);
        }
    },
    components:{
        Son1
    }
}
</script>