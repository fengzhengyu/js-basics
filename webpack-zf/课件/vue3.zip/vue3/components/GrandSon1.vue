<template>
    <div>
        GrandSon1 {{$attrs}}
        {{name}}
        {{parentMsg}}
        <!-- <button>{{$listeners.click()}}</button> -->
    </div>
</template>
<script>
export default {
    inject:['parentMsg'],
    props:['name'],
    methods:{
        fn(){
            alert('grandSon')
        }
    }
}
</script>