// import Vue from 'vue';
// Vue.prototype.$bus = new Vue();//需要一个公共的vue实例
// //son1
// this.$bus.on('test',function(msg){
//     console.log(msg);
// })
// //son2
// this.$bus.$emit('test',500)