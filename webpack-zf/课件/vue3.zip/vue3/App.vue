<template>
   <div>
       <Parent></Parent>
    </div> 
</template>

<script>
import Parent from "./components/Parent";
export default {
     components:{
         Parent
     } 
}
</script>