### vue
灵活  方便 比较好学 实用

vue+component+vue-router+vuex

### 框架和库
库:相当于功能比较全的产品，用时取库中的一部分产品来实现我们的功能
框架:为了解决一系类问题而生产出的产品,使用时只能按照他规定的模板来使用
vue是MVVM模式框架 

### {{}}语法

### 实例上的属性

### 指令  v-xxx  有特定的功能 ，可以操作DOM元素
v-for 遍历  想遍历谁，就在谁上面加v-for   key保证元素唯一性
v-text  默认会渲染成文本
v-html  渲染成标签  
v-once  只渲染一次，再次更改时,它是从缓存中获取，而不是再最新的数据
v-bind 简写成: 绑定动态的属性
v-on 简写成@   绑定事件
v-show true/false 更改DOM样式，让其显示和隐藏
v-if/v-else  操作DOM元素
v-model  双向绑定