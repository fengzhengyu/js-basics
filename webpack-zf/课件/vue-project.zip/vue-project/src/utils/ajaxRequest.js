import axios from 'axios';
class AjaxRequest {
    constructor(){
        this.baseURL = process.env.NODE_ENV ==="production" ?'/':"http://localhost:3000/api"
        this.timeout = 3000;
    }
    setInterceptor(instance,url){
        instance.interceptors.request.use((config)=>{
                
            config.headers.token = localStorage.getItem('token')||"";    
            return config
        },err=>Promise.reject(err))
        instance.interceptors.response.use((res)=>{
            if(res.data.code == 0){
                return res.data.data;
            }else{
                return Promise.reject(res.data);
            }    
        },err=>Promise.reject(err))
    }
    request(options){
          let instance = axios.create();
          let config = {
              ...options,
              baseURL:this.baseURL,
              timeout:this.timeout
          } 
         this.setInterceptor(instance,options.url);
        return instance(config);
    }
}
export default new AjaxRequest;