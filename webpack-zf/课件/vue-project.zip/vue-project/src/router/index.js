import Vue from 'vue'
import VueRouter from 'vue-router'
import Home from '@/views/Home'
import store from '@/store';
Vue.use(VueRouter)

const routes = [
  {
    path:'/',
    name:'home',
    component:Home
  },
  {
    path:'/course',
    name:'course',
    component:()=>import('@/views/Course'),
    meta:{
      needLogin:true
    }
  },
  {
    path:'/profile',
    name:'profile',
    component:()=>import('@/views/Profile')
  },
  {
    path:'/login',
    name:"login",
    component:()=>import('@/views/Login')
  }

  
]


const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})
router.beforeEach(async (to,from,next)=>{
      //1.判断是否登录过=> 如果登录过...
      //                => 如果没有登录过，判断下用户是否需要登录。。。
      try{
       
        await store.dispatch('validateUser');
        if(to.name =="/login"){
            next('/')
        }else{
            next();
        }
      }catch(e){
          let needLogin = to.matched.some(item=>item.meta.needLogin);
          if(needLogin){
            next('/login')
          }else{
            next();
          }
      }
      
})


export default router
