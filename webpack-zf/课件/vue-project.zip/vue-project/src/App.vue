<template>
  <div id="app">
    <div class="container">
    <router-view></router-view>
    </div>
    <div class="footer">
      <cube-tab-bar
        v-model="selectedLabelDefault"
        :data="tabs"
        @click="clickHandler"
      ></cube-tab-bar>
    </div>
    
  </div>
</template>
<script>
export default {
  data(){
    return {
      selectedLabelDefault: '/course',
      tabs: [{
        label: '首页',
        value:'/',
        icon: 'iconfont icon-shouye1'
      }, {
        label: '我的课程',
        value:'/course',
        icon: 'iconfont icon-zixun-weixuan'
      }, {
        label: '个人中心',
        value:'/profile',
        icon: 'iconfont icon-wode'
      }]
    }
    },
    watch:{
        // $route(to,form){  //只有这个属性发生改变时才会执行
        //   this.selectedLabelDefault = to.path; 
        // }
        $route:{
          handler(to,from){
            this.selectedLabelDefault = to.path; 
          },
          immediate:true  //默认先执行一遍
        }
    },
    methods:{
     clickHandler (label) {
      // if you clicked home tab, then print 'Home'
      this.$router.push(label);//组件会跟着导航链接切换
    },
    }


}
</script>
<style lang="less">
html,body,#app{
  height: 100%;
}
#app{
  display: flex; 
  flex-direction: column  //主轴的方向是纵向
}
.container{
  flex:1;
  overflow: scroll;
}
.footer{
  background:#f2f2f2;
}
.cube-tab {
  i{
    font-size: 22px;
  }
}
</style>
