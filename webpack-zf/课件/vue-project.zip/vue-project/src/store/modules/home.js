import {fetchCategory,fetchSlide} from "@/api/home.js";
export default {
    namespaced:true,
    state:{
        categories:[],
        slides:[],
        currentLesson:-1
    },
    mutations:{
        setCategories(state,payload){
            state.categories = payload;
        },
        setSlides(state,payload){
            state.slides = payload;
        },
        setCurrentLesson(state,value){
            state.currentLesson = value;
        }
    },
    actions:{
        async setCategories({commit}){
          let categories =  await fetchCategory();
          commit("setCategories",categories)
        },
        async setSlides({commit}){
            let slides = await fetchSlide();
            commit('setSlides',slides)
        }
    }
    //dispatch->commit->mutations
    //commit->mutations
}