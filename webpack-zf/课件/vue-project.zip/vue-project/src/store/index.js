import Vue from 'vue'
import Vuex from 'vuex'
import home from './modules/home';
import {Toast} from 'cube-ui';
import {fetchUser,validateUser} from '@/api/user.js';
Vue.use(Vuex)

export default new Vuex.Store({
  modules:{
    home
  },
  state: {
    user:{}
  },
  mutations: {
    setLogin(state,payload){
      state.user = payload;
    },
    validateUser(state,user){
        state.user = user;
    }
  },
  actions: {
    async setLogin({commit},user){
      try{
        let result  =  await fetchUser(user);
        commit('setLogin',result);
        localStorage.setItem('token',result.token);
      }catch(e){
         return Promise.reject(e);
      }
    },
    async validateUser({commit}){
      try{
        let user = await validateUser()
        commit('validateUser',user);
      }catch(e){
        Toast.$create({
          txt:e.data,
          time:500
        }).show()
        return Promise.reject(e);
      }
        
    }
  }
})
