import axios from '@/utils/ajaxRequest';
//提交用户名和密码
export const fetchUser = (user)=>{
    return axios.request({
        url:'/login',
        method:'post',
        data:user
    })
}

//验证用户是否登录
export const validateUser=(user)=>{
    return axios.request({
        url:'/validate'
    })
}