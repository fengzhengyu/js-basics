import axios from '@/utils/ajaxRequest';
import store from '@/store';
export const fetchCategory = ()=>{
    return axios.request({
        url:'/category'
    })
}
export const fetchSlide =()=>{
    return axios.request({
        url:"/slides"
    })
}
export const fetchLessonList =(size,offset)=>{
    return axios.request({
        url:`/lessonList/${store.state.home.currentLesson}?size=${size}&offset=${offset}`
    })
}