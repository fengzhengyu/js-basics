<template>
    <div class="profile">
        <div class="profile-banner" v-if="!user.username">
            <span class="photo"></span>
           <cube-button class="btn" :light="true" @click="toLogin">登录</cube-button>
        </div>
        <div class="profile-banner" v-else>
            <span class="photo"></span>
            <span class="btn-user">{{user.username}}</span>
        </div>
    
    </div>
</template>
<script>
import {mapState} from "vuex";
export default {
    computed:{
        ...mapState(['user'])
    },
    methods:{
        toLogin(){
            //得记录现在页面的路由链接
            this.$router.push({path:'/login',query:{from:"/profile"}})
        }
    }
}
</script>
<style scoped lang='less'>
.profile{
    height: 200px;
    background: url('../../assets/images/user_bg.png');
    background-color:blue;
    display:flex;
    flex-direction: column; //主轴的方式是垂直方向 ,交叉轴就是水平方向
    align-items: center;
    justify-content: center;
    .photo{
        background: url('../../assets/images/photo.png');
        width: 80px;
        height: 80px;
        background-size:cover;//contan
        display: block;
    }
    .btn{
       
        margin-top:20px;
        width: 100px;
        height: 50px;
    }
    .btn-user{
        color:#fff;
        margin-top:20px;
    }
}

</style>