<template>
<div>
    <div class="header">
        <img src="@/assets/images/logo.png" alt="" class="logo">
        <span class="iconfont icon-caidan" @click="show"></span>
    </div>
    <cube-drawer
  ref="drawer"
  title=""
  :data="data"
    @select="selectHandler"></cube-drawer>
</div>
</template>
<script>
export default {
    props:{
        categories:{
            type:Array,
            default:()=>[]
        }
    },
    computed:{
        data(){
            let defaultActive = [{text:'全部课程',value:-1}];
            return this.categories.length>0?[[...defaultActive,...this.categories]]:[defaultActive];
        }
    },
    methods:{
        show(){
            this.$refs.drawer.show();
        },
        selectHandler(value){
            this.$emit('change',value[0])
        }
    }
}
</script>
<style scoped>
    .header{
        height: 56px;
        display: flex;
        justify-content: space-between; 
        align-items: center;
        padding:0 20px;
        background: #2a2a2a;
    }
    .logo{
        width: 100px;
        height:50px;
    }
    .icon-caidan{
        color: #fff;
        font-size: 25px
    }
</style>