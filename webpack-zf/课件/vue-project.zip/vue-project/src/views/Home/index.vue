<template>
  <div>
    <HomeHeader :categories="categories" @change="change"></HomeHeader>
    <div class="home-slide">
      <cube-slide :data="slides" />
    </div>
    <h2 class="home-title">课程列表</h2>
    <div class="home-list">
      <cube-recycle-list class="list" :size="size" :on-fetch="onFetch" :offset="offset" ref="list">
        <template slot="item" slot-scope="{ data }">
          <div :id="data.id" class="item">
              <h2>{{data.title}}</h2>
              <img :src="data.pic" alt="">
              <p>{{data.price}}</p>
          </div>
        </template>
      </cube-recycle-list>
    </div>
  </div>
</template>
<script>
import HomeHeader from "./HomeHeader";
//import {mapState,mapActions} from 'vuex';
import { createNamespacedHelpers } from "vuex";
let { mapState, mapActions,mapMutations} = createNamespacedHelpers("home");
import { fetchLessonList } from "@/api/home.js";
export default {
  components: {
    HomeHeader
  },
  created() {
    this.size = 5;
    this.offset = 100;
    this.offsetIndex = 0;
    this.hasMore = true;
  },
  computed: {
    ...mapState(["categories", "slides"])
    // ...mapState('home',['categories'])
  },
  methods: {
    async onFetch() {
      if (this.hasMore) {
        let { hasMore, result } = await fetchLessonList(
          this.size,
          this.offsetIndex
        );
        this.hasMore = hasMore;
        this.offsetIndex = this.offsetIndex + result.length;
        return result;
      }else{
          return false;
      }
    },
    change(value) {
    //   this.$store.commit('setCurrentLesson',value)
        this.setCurrentLesson(value);
        this.hasMore = true;
        this.offsetIndex = 0;
        this.$refs.list.reset();
    },
    ...mapMutations(['setCurrentLesson']),
    ...mapActions(["setCategories", "setSlides"])
    //...mapActions('home',["setCategories"])
  },
  mounted() {
    this.setCategories();
    this.setSlides();
    // this.$store.dispatch('home/setCategories')
  }
};
</script>
<style lang="less">
.home {
  &-slide {
    width: 100%;
    height: 150px;
  }
  &-title {
    line-height: 35px;
    font-weight: bold;
    padding-left: 20px;
  }
}
img {
  width: 100%;
  height: 150px;
}
</style>