<template>
    <div>
        <Top>首页</Top>
        <img src="@/assets/images/login_bg.png" class="login-img">
        <div class="login-form">
    <cube-form :model="model" @submit="submitHandler">
        <cube-form-group>
            <cube-form-item :field="fields[0]"></cube-form-item>
            <cube-form-item :field="fields[1]"></cube-form-item>
        </cube-form-group>
        <cube-form-group class="btn">
            <cube-button type="submit">提交</cube-button>
        </cube-form-group>
        <cube-form-group>
            <cube-button type="reset">注册</cube-button>
        </cube-form-group>
</cube-form>

        </div>
        
        
    </div>
</template>
<script>
import Top  from '@/components/Top.vue';
import {mapActions} from 'vuex';
export default {
    data(){
        return {
             model:{
                 username:'',
                 password:''
             },
             fields:[
                 {
                type: 'input',
                modelKey: 'username',
                label: '用户名',
                props: {
                  placeholder: '请输入用户名'
                },
                rules: {
                  required: true
                }
              },
              {
                type: 'input',
                modelKey: 'password',
                label: '密码',
                props: {
                  placeholder: '请输入密码'
                },
                rules: {
                  required: true
                }
              }
             ] 
        }
    },
    components:{
        Top
    },
    methods:{
        ...mapActions(['setLogin']),
        submitHandler(e){
            e.preventDefault(); //阻止默认行为
            this.setLogin(this.model);
            //从哪来回到哪里去
            if(this.$route.query.from){
               this.$router.push(this.$route.query.from) 
            } else{
                this.$router.push('/profile')
            } 
        }
    }
}
</script>
<style scoped>
    .login-img{
        width: 80px;
        height: 80px;
        display: block;
        margin:50px auto;
    }
    .login-form{
        width: 80%;
        margin:0 auto;
    }
    .btn{
        margin-bottom:10px
    }
</style>