<template>
    <div>
        course
    </div>
</template>