<template>
    <div class="header-common">
        <i class="iconfont icon-back1" @click="back"></i>
        <slot></slot>
    </div>
</template>
<script>
export default {
    methods:{
        back(){
            this.$router.go(-1); //后退一步
        }
    }
}
</script>
<style scoped lang='less'>
    .header-common{
        line-height: 56px;
        height: 56px;
        background:#2a2a2a;
        text-align: center;
        color:#fff;
        i{
            position: absolute;
            left:15px;
        }
}
</style>