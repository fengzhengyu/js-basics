<template>
  <div id="app">
    <div class="form-group">
      <label>Search</label>
      <input type="text" v-model="searchCon"/>
    </div>
    <Table :searchCon="searchCon" :columns="columns" :dataList ="dataList"></Table>
  </div>
</template>
<script>
//props event slot
import Table from "@/components/Table";
export default {
  components: {
    Table
  },
  data() {
    return {
      searchCon:"",
      columns: [
        { title: "name" },
        { title: "age" },
        { title: "sex", gender: ["female", "male"] }
      ],
      dataList:[
        {name:"Lucy",age:10,sex:"female"},
        {name:"Jack",age:20,sex:"male"},
        {name:"Rose",age:30,sex:"female"}
      ]
    };
  }
};
</script>
