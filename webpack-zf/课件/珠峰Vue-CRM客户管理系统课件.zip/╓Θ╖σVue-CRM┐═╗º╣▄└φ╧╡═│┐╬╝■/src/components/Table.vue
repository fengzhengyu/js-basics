<template>
  <div>
    <table>
      <thead>
        <tr>
          <th v-for="col in columns" :key="col.title">{{col.title}}</th>
          <th>opearate</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="list in filterData" :key="list.name">
          <td v-for="col in columns" :key="col.title">{{list[col.title]}}</td>
          <td>
            <button class="btn-small" @click="updateDialog(list)">Update</button>
            <button class="btn-small" @click="deleteItem(list)">Delete</button>
          </td>
        </tr>
      </tbody>
    </table>
    <button class="btn" @click="newDialog">Create</button>
    <Dialog
      ref="child"
      :columns="columns"
      :mode="mode"
      :updateList="updateList"
      @createItem="createItem"
      @updateItem="updateItem"
    >{{title}}</Dialog>
  </div>
</template>
<script>
//组件内容部分称为插槽  <slot></slot>
//父组件： 子组件的标题 显示和隐藏
//子组件 ：新增和修改的数据给父组件
import Dialog from "@/components/Dialog";
export default {
  props: ["searchCon", "columns", "dataList"],
  components: {
    Dialog
  },
  data() {
    return {
      title: "",
      mode: 0, //1 新增 更新
      lists: this.dataList,
      updateList: {}
    };
  },
  computed: {
    filterData() {
      if (this.searchCon.length > 0) {
        return this.lists.filter(item => {
          return item.name.includes(this.searchCon);
        });
      } else {
        return this.lists;
      }
    }
  },
  watch: {
    mode() {
      if (this.mode == 1) {
        this.title = "Add Item";
      } else if (this.mode == 2) {
        this.title = "Update Item";
      }
    }
  },
  methods: {
    newDialog() {
      this.mode = 1;
      this.$refs.child.showDialog(true);
    },
    updateDialog(list) {
      this.mode = 2;
      this.updateList = list;
      this.$refs.child.showDialog(true);
    },
    deleteItem(list) {
      this.lists = this.lists.filter(item => {
        return item != list;
      });
    },
    createItem(aItem) {
      this.lists.push(aItem);
      this.$refs.child.showDialog(false);
    },
    updateItem(uItem) {
      this.lists = this.lists.map(item => {
        return item.name == uItem.name ? uItem : item;
      });
      this.$refs.child.showDialog(false);
    }
  }
};
</script>
