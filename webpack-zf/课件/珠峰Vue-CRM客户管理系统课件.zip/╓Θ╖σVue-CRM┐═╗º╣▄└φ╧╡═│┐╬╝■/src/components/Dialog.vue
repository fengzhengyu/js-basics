<template>
  <div>
      <div class="dialog dialog-active" v-if="show">
        <div class="dialog-content">
          <header class="dialog-header">
            <h1 class="dialog-title">
              <slot></slot>
            </h1>
          </header>
          <div class="dialog-body">
            <div class="form-group" v-for="col in columns" :key="col.title">
              <label>{{col.title}}</label>
              <select v-if="col.gender" v-model="item[col.title]">
                <option v-for="opt in col.gender" :value="opt">{{opt}}</option>
              </select>
              <input type="text" v-else  v-model="item[col.title]">
            </div>
          </div>
          <footer class="dialog-footer">
            <div class="form-group">
              <label for=""></label>
              <button class="btn" @click="save">save</button>
              <button class="btn" @click="showDialog(false)">close</button>
            </div>
          </footer>
        </div>
      </div>
  </div>
</template>
<script>
export default {
  props:["columns","mode","updateList"],
  data(){
    return {
      show:false,
      item:{}
    }
  },
  watch:{
    updateList(){
      this.item = JSON.parse(JSON.stringify(this.updateList));
    }
  },
  methods:{
    showDialog(show){
      this.show = show
    },
    save(){
      if(this.mode ==1){ //增加数据
          this.$emit("createItem",this.item);
      }else if(this.mode ==2){ //更新数据
          this.$emit("updateItem",this.item);
      }
      this.item ={}

    }
  }
}
</script>
