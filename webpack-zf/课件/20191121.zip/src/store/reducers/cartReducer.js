import * as TYPES from '../action-types';
const initState = {
	orderList: null,
	isSelectAll: true,
	isEdite: false,
	isSelectAllEdite: false
};
export default function cartReducer(state = initState, action) {
	state = JSON.parse(JSON.stringify(state));
	switch (action.type) {
		case TYPES.CART_ORDERALL:
			state.orderList = action.payload;
			state.orderList = state.orderList.map(item => {
				// 把从服务器获取的信息自定义一个是否被选中的属性
				item.isSelect = true;
				item.isSelectEdite = false;
				return item;
			});
			break;
		case TYPES.CART_UPDATE_SELECT_ALL:
			state.isSelectAll = action.flag;
			state.orderList = state.orderList.map(item => {
				if (parseInt(item.state) === 1) {
					item.isSelect = state.isSelectAll;
				}
				return item;
			});
			break;
		case TYPES.CART_UPDATE_SELECT:
			state.orderList = state.orderList.map(item => {
				if (parseInt(item.id) === parseInt(action.cartId)) {
					item.isSelect = action.flag;
				}
				return item;
			});
			const result = state.orderList.find(item => (parseInt(item.state) === 1 && item.isSelect === false));
			state.isSelectAll = result ? false : true;
			break;
		case TYPES.CART_UPDATE_SELECT_ALL_EDITE:
			state.isSelectAllEdite = action.flag;
			state.orderList = state.orderList.map(item => {
				if (parseInt(item.state) === 1) {
					item.isSelectEdite = state.isSelectAllEdite;
				}
				return item;
			});
			break;
		case TYPES.CART_UPDATE_SELECT_EDITE:
			state.orderList = state.orderList.map(item => {
				if (parseInt(item.id) === parseInt(action.cartId)) {
					item.isSelectEdite = action.flag;
				}
				return item;
			});
			const result2 = state.orderList.find(item => (parseInt(item.state) === 1 && item.isSelectEdite === false));
			state.isSelectAllEdite = result2 ? false : true;
			break;
		case TYPES.CART_UPDATE_EDITE:
			state.isEdite = action.flag;
			break;
		case TYPES.CART_UPDATE_COUNT:
			state.orderList = state.orderList.map(item => {
				if (parseInt(item.id) === parseInt(action.cartId)) {
					item.count = action.count;
				}
				return item;
			});
			break;
		case TYPES.CART_REMOVE:
			state.orderList = state.orderList.filter(item => {
				return parseInt(item.id) !== parseInt(action.cartId);
			});
			break;
	}
	return state;
};