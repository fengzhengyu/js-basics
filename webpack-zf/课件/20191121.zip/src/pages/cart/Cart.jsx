import React from 'react';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';
import './Cart.less';
import Recomend from './Recoment';
import Computed from './Computed';
import HeaderNav from '../../components/HeaderNav';
import Pay from '../../components/Pay';
import actions from '../../store/actions/index';
import api from '../../api/index';

//=>提示组件
function Tip(props) {
	// type = 0 未登录
	// type = 1 没有数据
	const type = props.type;
	return <div className="noTip">
		<i></i>
		{type === 0 ? <>
			您还没有登录~
			<Link to='/personal/login'>立即登录</Link>
		</> : '购物车该没有信息哦，先去逛逛吧~'}
	</div>;
}

class Cart extends React.Component {
	state = {
		payVisable: false
	};
	componentWillMount() {
		let baseInfo = this.props.baseInfo;
		if (!baseInfo) {
			//=>redux中没有信息，可能登陆也可能没登录，所以需要派发任务，从服务器同步登录态到redux中
			this.props.syncLoginInfo();
		}
	}
	render() {
		//=>从REDUX中获取购物车列表信息
		let { baseInfo, orderList, syncOrderList, updateSelect, isEdite, updateSelectEdite, updateEdite } = this.props;
		if (baseInfo && !orderList) syncOrderList();
		if (orderList) orderList = orderList.filter(item => parseInt(item.state) === 1);

		//=>获取PAY组件的状态
		let { payVisable, cartList } = this.state;

		return <section className="cartBox">
			<HeaderNav title="购物车">
				<span onClick={ev => {
					updateEdite(!isEdite);
				}}>{isEdite ? '完成' : '编辑'}</span>
			</HeaderNav>

			{!baseInfo ? <Tip type={0} /> : (!orderList || orderList.length === 0 ? <Tip type={1} /> : <div className="list">
				{orderList.map(item => {
					const S = isEdite ? item.isSelectEdite : item.isSelect,
						US = isEdite ? updateSelectEdite : updateSelect;
					return <Link to={'/detail/' + item.pid} className="clearfix" key={item.id}>
						<i className={S ? "check active" : "check"}
							onClick={ev => {
								ev.preventDefault();
								US(item.id, !S);
							}}></i>

						<div className="pic">
							<img src={item.info.pic} alt="" />
						</div>
						<div className="desc">
							<p>{item.info.title}</p>
							<p>￥{item.info.discount}</p>
						</div>
						<div className="count">
							<i className={parseInt(item.count) === 1 ? "minus disable" : "minus"} onClick={ev => {
								ev.preventDefault();
								this.handle('minus', item.count, item.id);
							}}></i>
							<input type="number" disabled
								value={item.count} />
							<i className="plus" onClick={ev => {
								ev.preventDefault();
								this.handle('plus', item.count, item.id);
							}}></i>
						</div>
					</Link>;
				})}
				<Computed updateVisable={this.updateVisable} />
			</div>)}

			{/* <Recomend /> */}
			<Pay payVisable={payVisable} orderList={orderList} updateVisable={this.updateVisable} />
		</section>;
	}
	updateVisable = flag => {
		this.setState({
			payVisable: flag
		});
	};
	handle = async (lx, count, cartId) => {
		if (lx === 'minus') {
			if (count <= 1) return;
			count--;
		} else {
			count++;
		}
		//=>向服务器发请求修改状态信息
		let result = await api.cart.update(cartId, count);
		if (parseInt(result.code) === 1) {
			window.alert('当前网络繁忙，请稍后再试~~');
			return;
		}
		//=>同步redux（最省事的方式：syncOrderList，性能好的方式：自己去修改redux中的信息）
		this.props.updateCount(cartId, count);
	};
}
export default connect(state => {
	return {
		...state.personal,
		...state.cart
	}
}, {
	...actions.personal,
	...actions.cart
})(Cart);