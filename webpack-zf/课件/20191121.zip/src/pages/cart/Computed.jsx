import React from 'react';
import { connect } from 'react-redux';
import './Computed.less';
import actions from '../../store/actions/index';
import api from '../../api/index';

function computedPrice(orderList) {
	if (!orderList) return 0;
	orderList = orderList.filter(item => parseInt(item.state) === 1);
	if (orderList.length === 0) return 0;
	return orderList.reduce((result, item) => {
		if (item.isSelect) {
			return result + (parseFloat(item.count * item.info.discount)) || 0;
		}
		return result;
	}, 0);
}

function handlePay(orderList) {
	if (!orderList) {
		window.alert('请选择您要支付的选项~~');
		return false;
	};
	orderList = orderList.filter(item => (parseInt(item.state) === 1 && item.isSelect === true));
	if (orderList.length === 0) {
		window.alert('请选择您要支付的选项~~');
		return false;
	}
	return true;
}

function handleRemove(orderList, props) {
	if (!orderList) {
		window.alert('请选择您要删除的选项~~');
		return;
	};
	orderList = orderList.filter(item => (parseInt(item.state) === 1 && item.isSelectEdite === true));
	if (orderList.length === 0) {
		window.alert('请选择您要删除的选项~~');
		return;
	}
	//=>一个个的去删除即可
	async function remove(orderList) {
		if (orderList.length === 0) {
			window.alert('选中的全部商品都已经被移除~~');
			return;
		};
		const item = orderList[0];
		const result = await api.cart.remove(item.id);
		if (parseInt(result.code) !== 0) {
			window.alert('删除失败，请稍后重试~~');
			return;
		}
		orderList.shift();
		props.removeCart(item.id);
		remove(orderList);
	}
	remove(orderList);
}

function Computed(props) {
	const { isSelectAll, updateSelectAll, orderList, isEdite, isSelectAllEdite, updateSelectAllEdite } = props;
	const SA = isEdite ? isSelectAllEdite : isSelectAll,
		USA = isEdite ? updateSelectAllEdite : updateSelectAll;
	return <div className="computedBox">
		<div className="check"
			onClick={ev => {
				USA(!SA);
			}}>
			<i className={SA ? 'active' : ''}></i>
			<span>全选</span>
		</div>

		{isEdite ? <div className="result">
			<button onClick={ev => {
				window.alert('客关请三思~~', {
					confirm: true,
					handled: type => {
						if (type === 'CONFIRM') {
							handleRemove(orderList, props);
						}
					}
				});
			}}>删除</button>
		</div> : <div className="result">
				<p>合计：<span>￥{computedPrice(orderList)}</span></p>
				<button onClick={ev => {
					if (handlePay(orderList)) {
						props.updateVisable(true);
					}
				}}>去支付</button>
			</div>}
	</div>;
}

export default connect(state => state.cart, actions.cart)(Computed);