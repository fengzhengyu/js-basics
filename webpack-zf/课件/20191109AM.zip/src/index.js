import React from 'react';
import ReactDOM from 'react-dom';
import Vote from './Vote';

ReactDOM.render(<>
	<Vote title="珠峰培训在线框架课很棒~~" />
	<Vote title="王燕老师很漂亮~~" />
</>, document.getElementById('root'));