<template>
     <el-submenu v-if="item.children.length" :index="item.auth">
        <template slot="title">{{item.name}}</template>
          <template v-for="(m,index) in item.children">
             <MenuItem :item='m' :key='index'></MenuItem>

          </template>
      </el-submenu>
      <el-menu-item v-else :index="item.auth">
        <!-- <span slot="title">{{item.name}}</span> -->
        <router-link :to="{name:item.auth}">{{item.name}}</router-link>
      </el-menu-item>
</template>
<script>
export default {
    name:'MenuItem',//组件名
    props:{
        item:{
            type:Object,
            default:()=>({})
        }
    }
}
</script>