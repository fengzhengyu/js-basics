<template>
    <div>
        cart
        <router-view></router-view>
    </div>
</template>