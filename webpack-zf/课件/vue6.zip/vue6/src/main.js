import Vue from 'vue'
import App from './App.vue'
import ElementUI from 'element-ui';
import 'element-ui/lib/theme-chalk/index.css';
import router from './router'
import store from './store'
Vue.use(ElementUI);
Vue.config.productionTip = false

router.beforeEach(async (to,from,next)=>{
    if(!store.state.hasPermission){
        //向后端发起请求是否有权限
     let newRoutes  =  await store.dispatch('getNewRoute') //返回有权限的路由（动态需要添加的路由）
     router.addRoutes(newRoutes) //动态添加路由
     next({...to});
    }else{
      next();
    }
})

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
