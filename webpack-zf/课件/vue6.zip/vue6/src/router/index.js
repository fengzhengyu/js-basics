import Vue from 'vue'
import VueRouter from 'vue-router'
import Home from '../views/Home.vue'

Vue.use(VueRouter)
export const authRoutes=[ //动态路由
    {
      path:'/cart',
      name:'cart',
      component:()=>import('@/views/Cart'),
      children:[
        {
          path:'cart-list',
          name:'cart-list',
          component:()=>import('@/views/CartList'),
          children:[
            {
              path:'lottery',
              name:'lottery',
              component:()=>import('@/views/Lottery')
            },
            {
              path:'product',
              name:'product',
              component:()=>import('@/views/Product')
            }
          ]
        }
      ]
    }
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes:[
    {
      path: '/',
      name: 'home',
      component: Home
    },
    {
      path:'*',
      component:{
        render:h=>h('h1',{},'Not Found')
      }
    }
  ]
})

export default router
