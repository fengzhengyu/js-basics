const webpack = require('webpack');
const { BundleAnalyzerPlugin } = require('webpack-bundle-analyzer');
module.exports = {
    mode:"development",
    devServer: {
        port: 7878,
        compress: true,
        hot: true
    },
    plugins:[
        new webpack.HotModuleReplacementPlugin(),
         // new BundleAnalyzerPlugin()
    ]
}