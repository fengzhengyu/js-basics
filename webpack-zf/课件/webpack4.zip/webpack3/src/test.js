const minus = (a,b)=>{
    return a-b+2+4+4;
}
export default minus;