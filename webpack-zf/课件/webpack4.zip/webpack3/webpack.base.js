const dev = require('./webpack.dev');
const prod = require('./webpack.prod');
const path = require('path');
const merge = require('webpack-merge');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const MiniExtractPlugin = require('mini-css-extract-plugin');
const { CleanWebpackPlugin } = require('clean-webpack-plugin');
const webpack = require('webpack');

let htmlPlugs = ["index", "other"].map(chunkName => {
    return new HtmlWebpackPlugin({
        template: path.resolve(__dirname, `./${chunkName}.html`),
        filename: `${chunkName}.html`,
        chunks: [`${chunkName}`]
    })
})
module.exports = (env) => {
   
    let base = {
        // devtool:"cheap-module-eval-source-map",
        // externals:{
        //      "jquery":"$"  //如果是第三方库jquery就不需要打包     
        // },
        optimization: {
            splitChunks: {
                chunks: 'all',
                minSize: 30000,
                minChunks: 1,
                maxAsyncRequests: 5,
                maxInitialRequests: 3,
                automaticNameDelimiter: '~',
                name: true,
                cacheGroups: {
                    vendors: {
                        test: /[\\/]node_modules[\\/]/,
                        priority: -10
                    },
                    default: {
                        minChunks: 1,
                        priority: -2,
                        reuseExistingChunk: true
                    }
                }
            }
        },
        entry: {
            index: './src/index.js',
            // other:'./src/other.js'
        },
        output: {
            filename: '[name].js',
            path: path.resolve(__dirname, 'dist'),
            chunkFilename: "[name].min.js"  //异步请求的文件名
        },
        plugins: [

            //new CleanWebpackPlugin(),
            // new MiniExtractPlugin({
            //     filename:"css/main.css"
            // }),
            new HtmlWebpackPlugin({
                template: path.resolve(__dirname, './index.html'),
                filename: "index.html",
                //  chunks:["index"]
            }),
            // new HtmlWebpackPlugin({ 
            //     template: path.resolve(__dirname, './other.html'),
            //     filename: "other.html",
            //     chunks:["other"]
            // }),
            //...htmlPlugs,
            // new webpack.ProvidePlugin({ //可以把变量变成每个模块都能使用，但是不是放window上
            //       "$" : "jquery"  //$变量是jquery中
            // })
        ],
        module: {
            rules: [
                // {
                //     test:/\.js$/,
                //     use:"eslint-loader",
                //     exclude:/node_modules/,
                //     // include:path.resolve(__dirname,"src/**/*")
                //     enforce:'pre'  //在所有规则之前先校验代码
                // },
                // {
                //     test:require.resolve('jquery'),
                //     use:{
                //         loader:"expose-loader",  //window.$
                //         options:"$"
                //     }
                // },
                // {
                //     test:/\.html$/,
                //     use:"html-withimg-loader"
                // },
                {
                    test: /\.css$/,
                    use: [
                        // {
                        //     loader:MiniExtractPlugin.loader
                        // },
                        {
                            loader: 'style-loader'
                        },
                        {
                            loader: "css-loader",
                            options: {
                                importLoaders: 2
                            }
                        }, "postcss-loader", "less-loader"
                    ]
                },
                {
                    test: /\.less$/,
                    use: ["style-loader", "css-loader", "less-loader"]
                },
                {
                    test: /\.(png|jpe?g|gif)$/,
                    use: [
                        { loader: 'file-loader' },
                        {
                            loader: 'image-webpack-loader',
                            options: {
                                mozjpeg: {
                                    progressive: true,
                                    quality: 65
                                },
                                // optipng.enabled: false will disable optipng
                                optipng: {
                                    enabled: false,
                                },
                                pngquant: {
                                    quality: [0.65, 0.90],
                                    speed: 4
                                },
                                gifsicle: {
                                    interlaced: false,
                                },
                                // the webp option will enable WEBP
                                webp: {
                                    quality: 75
                                }
                            }
                        },
                    ]
                },
                {
                    test: /\.(eot|svg|ttf|woff|woff2)$/,
                    use: "file-loader"
                },
                {
                    test: /\.js$/,
                    use: {
                        loader: "babel-loader"

                    }

                }
            ]
        }
    }
     if(env.development){
       return merge(base,dev);  
     }else{
        return merge(base,prod);
     }
    //如果是开发环境  base dev合并
    //如果是生产环境  base prod 合并
    //合并 webpack-merge
}
