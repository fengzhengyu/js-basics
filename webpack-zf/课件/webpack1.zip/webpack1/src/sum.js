//node 模块  
//module.exports  exports
//require

//es6 esmodule 
//export default ...
//import 

export default function(a,b){
    return a+b;
}
