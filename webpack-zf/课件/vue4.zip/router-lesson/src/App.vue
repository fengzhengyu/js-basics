<template>
  <div>
    <el-container>
      <el-header>
        <!-- <router-link to="/">首页</router-link>
        <router-link to="/profile">个人中心</router-link>
        <router-link to="/user">用户界面</router-link>-->
        <el-menu
          mode="horizontal"
          :router="true"
          background-color="#545c64"
          text-color="#fff"
          active-text-color="#ffd04b"
        >
          <el-menu-item index="/">首页</el-menu-item>
          <el-menu-item index="/profile">个人中心</el-menu-item>
          <el-menu-item index="/user">用户界面</el-menu-item>
        </el-menu>
      </el-header>
      <el-main>
        <!-- 路由对应的组件 -->
        <router-view></router-view>
      </el-main>
      <el-footer>Footer</el-footer>
    </el-container>
  </div>
</template>
<style>
.el-header,
.el-footer {
  background-color: #b3c0d1;
  color: #333;
  text-align: center;
  line-height: 60px;
}
.el-main {
  background-color: #e9eef3;
  min-height: calc(100vh - 120px);
}
</style>

