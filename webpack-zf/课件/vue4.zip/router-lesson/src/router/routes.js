//1.引入路由组件
import Home from '../views/Home';
import Profile from '../views/Profile';
import User from '../views/User';

//2.设置映射表 路由和组件的对应关系
let routes = [
    {
        path:'/home',
        name:"home",
        component:Home
    },
    {
        path:'/profile',
        name:'profile',
        component:Profile,
        meta:{
            needLogin:true
        }
    },
    {
        path:'/user',
        name:'user',
        component:User,
        children:[
            {
                path:"add",
                component:()=>import('../views/UserAdd.vue')
            },
            {
                path:"list",
                component:()=>import('../views/UserList.vue')
            },
            {
                path:"detail/:id",
                component:()=>import('../views/UserDetail.vue')
            }
        ]
    },
    {
        path:'*',
        redirect:{
            path:'/home'
        }
    }
]
export default routes;