<template>
    <div>
        <!-- 路由传参 /detail/2 问号传参 /detail?id=2 -->
        {{$route.params.id}}   
        <!-- {{$route.query.id}} -->
        
    </div>
</template>
<script>
export default {
    data(){
        return {
           
        }
    },
    // beforeRouteEnter(to,form,next){
    //     console.log(1);
    //     next();
    // },
    // beforeRouteUpdate(to,form,next){
    //     console.log(更新了);
    // }
    watch:{
        $route(){  
            console.log('111');
        }
       
    }

}
</script>