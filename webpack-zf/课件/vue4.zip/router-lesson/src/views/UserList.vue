<template>
  <div>
    <el-table :data="tableData" style="width: 100%">
      <el-table-column prop="username" label="用户名" width="300px"></el-table-column>
      <el-table-column>
        <template slot-scope="scope">
        <router-link type="text" size="small" :to="`/user/detail/${scope.row.id}`">详情</router-link>
      </template>
      </el-table-column>
     
    </el-table>
  </div>
</template>
<script>
export default {
    data(){
        let tableData = JSON.parse(localStorage.getItem('lists'));
        return {
            tableData
        }
    }
}
</script>