import Vue from 'vue'
import ElementUI from 'element-ui';
import 'element-ui/lib/theme-chalk/index.css';
import App from './App.vue'
import router from './router';
 Vue.use(ElementUI);

Vue.config.productionTip = false
router.beforeEach((to,from,next)=>{
  //只有有一项为true则为true  some 
    if(to.matched.some(m=>m.meta.needLogin)){ //需要登录
        if(localStorage.getItem('login')){ //有没有登录   login true false  
            next();
        }else{
            next('/');
        }
    }else{
      next(); //一定要记得写    
    }
})
new Vue({
  router,  //$router 方法 $route 属性
  render: h => h(App)
}).$mount('#app')
