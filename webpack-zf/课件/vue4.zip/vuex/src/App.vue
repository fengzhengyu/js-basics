<template>
    <div>
        <div>{{lesson}}</div>
        <div>{{room}} <button @click="changeRoom">更改</button></div>
        <div>{{getNewName}}</div>
        <div>{{userName}} {{getUserName}}</div>
    </div>  
</template>
<script>
import {mapState,mapGetters,mapMutations} from "vuex";
//console.log(mapState(['lesson','room']))//this.lesson this.$store.state.lesson
console.log(mapMutations(['change_room']));
export default {
    computed:{
        ...mapState(['lesson','room']),
        ...mapGetters(['getNewName']),
        ...mapState('user',['userName']),
        ...mapGetters('user',['getUserName'])
    },
    methods:{
        changeRoom(){
            //this.$store.commit('change_room','302')
            // this.$store.commit('user/change_name','wy')
            this.$store.dispatch('change_room','2222');
            // this.$store.dispatch({
            //     type:'change_room',
            //     r:"222222"
            // });
            //this.$store.state.lesson="就业课" 严格模式下不可以
        } 
    }
}
//vue项目  单元测试 JWT  vue性能优化....
//vue知乎(作业)  vue知乎项目
//菜单组件  CRM组件传递 
</script>