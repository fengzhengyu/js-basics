export default {
    getNewName:(state)=>{
        return '珠峰'+state.lesson
    }
}