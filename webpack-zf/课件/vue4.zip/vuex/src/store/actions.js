export default{
    //action里面调用commit->mutation
    change_room({commit},payload){
        setTimeout(()=>{
            commit("change_room",payload)
        },2000)
       
    }
}