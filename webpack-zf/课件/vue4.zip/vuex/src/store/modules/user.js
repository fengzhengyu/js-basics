export default {
    namespaced:true,//指定命名空间
    state:{
        userName:'zf'
    },
    actions:{

    },
    getters:{
        getUserName:(state)=>{
            return "my"+state.userName
        }    
    },
    mutations:{
        change_name(state,payload){
            state.userName = payload;
        }
    }
}