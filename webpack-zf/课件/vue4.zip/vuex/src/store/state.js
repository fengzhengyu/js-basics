export default {
    lesson:'框架课',
    room:'204'
}