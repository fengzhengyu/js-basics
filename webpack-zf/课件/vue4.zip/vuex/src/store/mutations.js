export default {
    change_room:(state,payload)=>{
        state.room = payload;
    }
}