import Vue from 'vue'
import App from './App.vue'
import store from './store'

Vue.config.productionTip = false

new Vue({
  store, //所有的组件都可以用$store
  render: h => h(App)
}).$mount('#app')
