<template>
  <div id="app">
      <button @click="showMessage">点我弹层</button>
  </div>
</template>
<script>
//Vue.component(Button) 
//Vue.use(Button)  
//this.$message  第二种调用插件的方式
// import {Message} from '' 第一种方式
//import {Message} from "./components/Message";
import Vue from 'vue';
import Message from './components/Message';
Vue.use(Message,{duration:1000}); //install
export default {
    methods:{
      showMessage(){
          this.$message.info({
            message:'你好',
            duration:3000
          })
      }

    }
}
</script>

