import Vue from 'vue';
import MessageComponent from './Message.vue';
let getInstance = ()=>{
    let vm = new Vue({
        render:h=>h(MessageComponent)
    }).$mount()  //挂载到内存上
      document.body.appendChild(vm.$el);
      //1.如何拿到MessageComponent组件 2.调用add方法
      //$parent $children
       let component = vm.$children[0];
       //add 
       return {
            add(options){
                component.add(options);//主体不会边 Message组件
            }
           
       }
}
// 单例模式 防止多次初始化vue
let instance;
let getIns = ()=>{
    instance = instance ||getInstance()
    return instance
}
const Message = {
    info(options){
        getIns().add(options);
    },
    error(){},
    success(){}
}
export {
    Message
}
 
export default {
    install(Vue,options){ //options是use的第一个参数  
        //1.Message 里的方法放入$message里
        //2.$message放在原型上暴露在全局
        let $message = {};
        Object.keys(Message).forEach(type=>{
              $message[type] = Message[type];  
        });
        Vue.prototype.$message = $message
        // Vue.mixin({  
        //     beforeCreate(){
                    
        //     }
        // })
    }
}
