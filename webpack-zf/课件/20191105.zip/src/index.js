import React from 'react';
// REACT的核心：基础语法、属性、状态、生命周期、组件等
import ReactDOM from 'react-dom';
// 把虚拟DOM渲染成为真实的DOM
import './index.less';
import { createElement, render } from './selfJSX';

render(createElement("div", {
	className: "box",
	style: {
		fontSize: '20px'
	},
	index: 0
}, "\u73E0\u5CF0\u57F9\u8BAD\u5728\u7EBF\u6846\u67B6\u8BFE\u9650\u65F6\u4F18\u60E0"), document.getElementById('root'));

// ReactDOM.render(JSX语法,容器,渲染完触发的回调函数)
// VUE template
// REACT JSX（JAVASCRIPT AND XML[HTML]）
// {}存放的是JS表达式
// 不能直接放入对象（除数组和几种特殊情况外：style必须设置成为对象值才可以、虚拟DOM对象没问题）
// 样式类名：className
// null和undefined代表空元素

// let str = "在线框架课限时优惠，赶快报名！";
// let obj = {
// 	fontSize: '20px'
// };
// let arr = [10, 20, 30];
// let level = 1;

// ReactDOM.render(<>
// 	<span className="box" style={obj}>珠峰培训</span>
// 	{arr.map(item => {
// 		return <a href="" key={item}>{item}</a>;
// 	})}
// </>, document.getElementById('root'));

// 虚拟DOM（JSX）=> 真实DOM（渲染在页面）

// ReactDOM.render(<div
// 	className="box"
// 	style={{
// 		fontSize: '20px'
// 	}}
// 	index={0}>
// 	珠峰培训在线框架课限时优惠
// </div>, document.getElementById('root'));

// 1.基于babel-preset-react-app把JSX变为React.createElement(...)
// 第一项：标签名（或者函数组件/类组件）
// 第二项：给标签设置的属性 null
// 第三项或者更多项：标签的子节点（文本节点或者元素节点）=>所有的元素节点都会重新React.createElement
/* let JSXOBJ = React.createElement("div", {
	className: "box",
	style: {
		fontSize: '20px'
	},
	index: 0
}, "\u73E0\u5CF0\u57F9\u8BAD\u5728\u7EBF\u6846\u67B6\u8BFE\u9650\u65F6\u4F18\u60E0", React.createElement("a", null));

console.log(JSXOBJ); */

// 2.执行React.createElement()创建JSX虚拟DOM对象
// {
//    type:标签名或者组件
//    props:{
//       className:'xxx' 我们传递的属性
//       children: 子节点内容（特点：没有子节点则没有这个属性，否则是一个或者一个数组）
// 	  }
// }

// 3.ReactDOM.render把虚拟DOM对象变为真实的DOM对象（渲染到页面中）


// 4.Vue-loader把template语法解析为虚拟DOM对象 _vnode