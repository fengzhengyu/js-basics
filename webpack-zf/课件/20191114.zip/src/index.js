import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';
import { HashRouter } from 'react-router-dom';
/* REDUX */
import { Provider } from 'react-redux';
import store from './store/index';

ReactDOM.render(<Provider store={store}>
	<HashRouter>
		<App />
	</HashRouter>
</Provider>, document.getElementById('root'));

/*
 * 路由的两种实现方案
 *   1. HASH路由
 *     http://www.xxx.com/#AA
 *     http://www.xxx.com/#BB
 *     window.onhashchange=function(){}
 *
 *   2. BROWSER路由 H5 History API
 *     =>需要服务器配合
 *     基于History API中的pushState进行地址切换的时候，页面不刷新，地址也会改，我们监听到改变后实现组件的切换；但是，当手动刷新，如果当前跳转的页面不存在，会报错，需要服务器对于不存在的页面做特殊的处理；
 */