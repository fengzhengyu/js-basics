import React from 'react';
export default function Login(props) {
	console.log(props);
	return <>
		登录
	</>;
}