import React from 'react';
export default function Register(props) {
	return <>
		注册
	</>;
}