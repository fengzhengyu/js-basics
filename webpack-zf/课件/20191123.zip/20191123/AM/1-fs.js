/*
 * fs内置模块赋予了JS在NODE环境下操作I/O的能力 
 */
const fs = require('fs');
// const fsPromises = fs.promises;

//=>1.readFile/readFileSync：读取文件中的内容，默认返回的是Buffer流格式，指定utf8让其变为字符串
// const text = fs.readFileSync(`${__dirname}/package.json`, 'utf8');

//=>默认I/O的异步操作是基于回调函数处理的
// fs.readFile(`${__dirname}/package1.json`, 'utf8', (err, result) => {
// 	if (err) {
// 		console.dir(err);
// 		return;
// 	}
// 	console.log(result);
// });

// fsPromises.readFile(`${__dirname}/package.json`, 'utf8').then(result => {
// 	console.log(result);
// }).catch(err => {
// 	console.log("报错拉~~" + err);
// });

/*
 * 导入自己的FS库 
 */
// const fsPromise = require('./lib/myFs');
// fsPromise.readFile('./package1.json')
// 	.then(result => {
// 		console.log(result);
// 	}).catch(err => {
// 		console.log(err);
// 	});

/*
 * 写入内容  writeFileSync覆盖式写入（appendFile）
 *   path:不存在会默认创建一个
 *   data:必须是字符串格式
 */
fs.writeFileSync('./1.txt', '你好世界~~', 'utf8');
fs.writeFile('./1.txt', '珠峰培训~~', 'utf8', err => {
	// console.log(err);
});