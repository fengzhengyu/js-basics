console.log(0);
setTimeout(() => {
	console.log(1);
}, 100);
setImmediate(() => {
	console.log(3);
}); //=>和setTimeout(0)比较类似  放置到Event Queue的最顶部（也就是主队列执行完，首先执行的就是他）
// setTimeout(() => {
// 	console.log(2);
// }, 0); //=>0不是立即执行，也需要等待（它是优先于setImmediate）
process.nextTick(() => {
	//=>执行下一个任务  放置在主任务队列的末尾，也就是主任务一执行完，先执行process.nextTick，然后再去Event Queue中查找
	console.log(4);
});
console.log(5);