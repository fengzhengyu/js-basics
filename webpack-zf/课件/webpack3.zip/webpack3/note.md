### 暴露全局变量
  1）直接使用cdn的方式
  2）providePlugin  '$':'jquery'
  3)暴露的方式   expose-loader   
### 添加eslint.js
1)手动的 2）自动
安装`eslint`
```bash
npm install eslint  eslint-loader
npx eslint --init # 初始化配置文件
```

```
{
    test:/\.js/,
    enforce:'pre',
    use:'eslint-loader'
},
```

> 配置`eslint-loader`可以实时校验js文件的正确性,`pre`表示在所有`loader`执行前执行

### sourceMap(代码排查)
https://webpack.docschina.org/configuration/devtool/
 https://www.cnblogs.com/wangyingblog/p/7027540.html
- eval 生成代码 每个模块都被eval执行,每一个打包后的模块后面都增加了包含sourceURL
- source-map 产生map文件
- inline 不会生成独立的 .map文件,会以dataURL形式插入
- cheap  忽略打包后的列信息，不使用loader中的sourcemap
- module 没有列信息，使用loader中的sourcemap(没有列信息)

### 开发环境推荐：
开发环境:
cheap-module-eval-source-map
生产环境推荐：
cheap-module-source-map

### 图片压缩
- image-webpack-loader
### 根据Mode分离配置环境
### Tree-shaking (生成环境下)
- sideEffects 
### Scope-Hoisting 
webpack4 后不用配，天生自带 减少作用域提升性能
### 热更新
- hot:true
- HotModuleReplacementPlugin
- module.hot.accept 
### 懒加载(动态加载)
+ webpackChunkName  chunkFilename
+ webpackPrefetch
+ webpackPreload
+ @babel/plugin-syntax-dynamic-import
+ @babel/preset-react
### 打包文件分析工具 (生成环境下使用)
默认就会展现当前应用的分析图表
安装webpack-bundle-analyzer插件
const {BundleAnalyzerPlugin} = require('webpack-bundle-analyzer');
### DllPlugin && DllReferencePlugin   (一般用在开发环境下)
把第三方库打包成动态链接库,以后构建时只需要查找构建好的库就好了，这样可以大大节约构建时间
-add-asset-html-webpack-plugin
### 多入口多出口
### SplitChunks
编译时抽离第三方模块、公共模块
 ### happypack
多线程打包，可以讲不同的逻辑交给不同的线程来处理


