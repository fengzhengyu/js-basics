// require('expose-loader?$!jquery');
//import $ from 'jquery'; //同步代码
//import('jquery') //异步代码
//console.log($);
// import "./a"
// console.log(window.$)
//import test from './test'; //是副作用
// import "./index.css";
 import minus from './test';

let btn = document.createElement('button');
let p = document.createElement('p');
 btn.innerHTML = "BUTTON";
  p.innerHTML = minus(10,5);

//js内容更改后也可以热更新
if(module.hot){
    module.hot.accept("./test",()=>{ 
        let minus = require('./test').default;
         p.innerHTML = minus(10,5)
   })
}
// //懒加载是使用到了后才去加载 import()
// btn.addEventListener("click",function(){
//     import(/*webpackChunkName:"c"*/"./test").then(({default:m})=>{
//             p.innerHTML = m(20,10);
//     })
// },false)
  document.body.appendChild(btn);
  document.body.appendChild(p);


 