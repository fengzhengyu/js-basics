const minus = (a,b)=>{
    return a-b+2+4+4+21+2;
}
export default minus;