// require('expose-loader?$!jquery');
console.log(window.$);