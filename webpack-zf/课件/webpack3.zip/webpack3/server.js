let express = require("express");
let app  = express();
app.get('/user',function(req,res){
    console.log(req.headers);
    res.json({name:'zf'})
})
app.listen(6000,function(){
    console.log("服务启动了")
}); //创建了一个端口号为6000这个服务