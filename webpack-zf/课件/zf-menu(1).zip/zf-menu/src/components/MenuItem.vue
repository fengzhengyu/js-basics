<template>
    <li>
        <slot></slot>
    </li>
</template>