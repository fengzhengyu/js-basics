<template>
  <Menu>
    <template v-for="menu in data">
      <MenuItem :key="menu.id" v-if="!menu.children">{{menu.title}}</MenuItem>
      <ReSubMenu :data="menu" v-else></ReSubMenu>
    </template>

    <!-- <MenuItem>菜单2</MenuItem> -->
    <!-- <SubMenu>
      <template #title>菜单3</template>
      <MenuItem>菜单3-1</MenuItem>
      <MenuItem>菜单3-2</MenuItem>
      <SubMenu>
        <template #title>菜单3-1</template>
        <MenuItem>菜单3-11</MenuItem>
        <MenuItem>菜单3-12</MenuItem>
      </SubMenu>
    </SubMenu>-->
  </Menu>
</template>
<script>
import Menu from "./Menu";
import MenuItem from "./MenuItem";
import SubMenu from "./SubMenu";
import ReSubMenu from "./ReSubMenu";
export default {
  props: {
    data: {
      type: Array,
      default: () => ([])
    }
  },
  components: {
    Menu,
    MenuItem,
    SubMenu,
    ReSubMenu
  }
};
</script>