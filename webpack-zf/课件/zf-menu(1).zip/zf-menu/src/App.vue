<template>
    <MenuList :data = "menuList"></MenuList>
</template>
<script>
//props $on $emit $parent $children $attrs(v-bind) $linsteners(v-on)
//Provide/inject vuex
//全局组件 局部组件 函数组件 递归组件
//1.定义创建 2.注册组件  3.使用组件
import MenuList from "./components/MenuList";
import axios from "axios";
export default {
    async created(){
       let {data} =  await axios.get("menu.json");
       this.menuList = data;
    },
    data(){
      return {
          menuList:[]
      }
    },
    components:{
      MenuList
    }
}
</script>
