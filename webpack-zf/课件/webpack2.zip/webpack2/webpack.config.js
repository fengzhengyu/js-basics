//commonjs规范
const path = require('path');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const MiniExtractPlugin = require('mini-css-extract-plugin');
const TerserJSPlugin = require('terser-webpack-plugin'); //压缩js
const OptimizeCSSAssetsPlugin = require('optimize-css-assets-webpack-plugin');
const { CleanWebpackPlugin } = require('clean-webpack-plugin');
module.exports = {
    
    entry: './src/index.js',
    output: {
        filename: 'bundle.js',
        path: path.resolve(__dirname, 'dist') //返回绝对路径
    },
    optimization: {
        minimizer: [new TerserJSPlugin({}), new OptimizeCSSAssetsPlugin({})],
     },
    devServer: {
        port: 9999,
        // open: true,
        compress: true,//启动gzip压缩
        contentBase: "aa",  //aa目录的静态资源文件也可以直接访问
        before(app){  //after  以9999端口号创建一个服务,这样没有跨域问题
            app.get("/api/user",function(req,res){
                console.log(res.json({name:"zf"}))
            })
        }
        // proxy:{
        //     "/api":{
        //         target:"http://localhost:6000", //设置请求的服务器地址,
        //         // secure:false,//代理的服务器是https
        //         changeOrigin:true,//把请求头里host的地址改成服务器地址
        //         pathRewrite:{"/api":""}   //重写路径

        //     }
        // }

    },
    plugins: [
        new CleanWebpackPlugin(),
        new MiniExtractPlugin({
            filename:"css/main.css"
        }),
        new HtmlWebpackPlugin({  //把打包后的js自动的引用到新生成的html文件
            template: path.resolve(__dirname, './index.html'),
            filename: "index.html"
        })
    ],
    module: {  //确定下对什么文件去转化,怎么转化 ,需要哪些loader
        //use "" [] {}  
        // 从下往上  从右往左
        rules: [
            {
                test:/\.html$/,
                use:"html-withimg-loader"
            },
            {
                test: /\.css$/,
                use: [
                    {
                        loader:MiniExtractPlugin.loader
                    },
                    {
                    loader: "css-loader",
                    options:{
                        importLoaders:2  //用后面几个加载器来解析
                    }
                },"postcss-loader","less-loader"
                ]
            },
            {
                test: /\.less$/,
                use: ["style-loader", "css-loader", "less-loader"]
            },
            {
                test:/\.(png|jpe?g|gif)$/,
                use:{
                   loader: "url-loader",  //10kb以内的通过url-loader转换成base64,大于10kb通过file-loader拷贝一份放在dist目录下
                   options:{
                       limit:10*1024,  //100kb
                    //    name:`img/[name].[ext]`
                       outputPath:'img'
                    //    publicPath:'http://www.zhufengpeixun.cn/img'
                   }
                }
            },
            {
                test:/\.(eot|svg|ttf|woff|woff2)$/,
                use:"file-loader"
            },
            {
                test:/\.js$/,
                use:{
                    loader:"babel-loader"  
                }

            }
        ]
    }
}
 //npx webpack
 // 每次打包后的js要插入到html中，在浏览器端查看
 // webpack-dev-server   配置开发服务
 // css-loader style-loader
// less sass stylus 
//less less-loader
//node-sass sass-loader
//stylus stylus-loader
//postcss-loader  样式处理工具 可以借助自定义的插件从而重新定义css
//加私有前缀的插件 atuoprefixer
//clean-webpack-plugin  清理输出的目录
//html-withimg-loader  处理html文件中的图片的