class Father{

}
export default Father;