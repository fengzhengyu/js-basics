// import sum from "./sum";
// import "./index.css";
// console.log(sum(10,5))


// import "./icon/iconfont.css";
// import url from "./timg.jpeg";
// let img = new Image();
// img.src = url;
// document.body.appendChild(img);

// let i = document.createElement("i");
// i.className = "iconfont icon-dianyingpiao";
// document.body.appendChild(i);

//file-loader  url-loader




// let p = new Promise((resolve,reject)=>{
//     console.log(1);
// }) 
// console.log("zhufeng".includes('z'))
// import A from "./a";

// class Son{
//     constructor(){
//         this.a =1;
//     }
// }
// let s  = new Son();
// console.log(s.a);

//babel 
//babel-loader  babel和webpack的桥梁
//@babel/core babel的核心模块
//@babel/preset-env 主要是把es6转换成es5 插件的集合

//草案语法 
// @fn 
// class Son{
//     a = 1;
// }
// function fn(target){
//     // console.log(target);
//     target.b = 5
// }
// let s = new Son();
// console.log(s.a)

let xhr  = new XMLHttpRequest();
xhr.open('get',"/api/user",true)
xhr.onreadystatechange = function(){
    console.log(xhr.response)
}
xhr.send();


