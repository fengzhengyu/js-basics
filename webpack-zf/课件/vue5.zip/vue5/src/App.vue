<template>
  <div>
    <Tree 
    :data.sync='data' 
    :fileDrop = "fileDrop"
    :directoryDrop ="directoryDrop"
    :delete = 'deleteFn'
    ></Tree>
  </div>
</template>
<script>
import Tree from './Tree.vue';
import {getTreeList} from './api' 
export default {
    components:{
      Tree
    },
    methods:{
        deleteFn(id){
            return new Promise((resolve,reject)=>{
              setTimeout(()=>{
                  resolve()
              },2000)
            })
        }
    },
    data(){
      return {
        data:[],
        fileDrop:[
          {text:'rm',value:'删除文件'}
        ],
        directoryDrop:[
          {text:'rn',value:'修改名字'},
          {text:'rm',value:'删除文件夹'}
        ]
      }
    },
    async mounted(){
    let {data} =  await getTreeList();
       data.parent.forEach(p=>p.type='parent');
       this.data = [...data.parent,...data.child];
    }
}
</script>