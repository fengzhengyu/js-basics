import axios from 'axios';
axios.defaults.baseURL = "http://localhost:9999"; //公共路径部分
export const getTreeList  = ()=>{
    return axios.get('/getTreeList');
}

