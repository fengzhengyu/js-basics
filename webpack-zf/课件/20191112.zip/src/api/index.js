import task from './task';
export default {
	task
};