import * as TYPES from '../action-types';
const initState = {
	isLogin: false,
	baseInfo: null
};
export default function personalReducer(state = initState, action) {
	state = JSON.parse(JSON.stringify(state));
	switch (action.type) {
		case TYPES.PERSONAL_LOGIN_SUCCESS:
			state.isLogin = true;
			state.baseInfo = action.payload;
			break;
		case TYPES.PERSONAL_LOGIN_INFO:
			state.isLogin = action.isLogin;
			state.baseInfo = action.baseInfo || null;
			break;
	}
	return state;
};