import * as TYPES from '../action-types';
const initState = {
	orderList: null
};
export default function cartReducer(state = initState, action) {
	state = JSON.parse(JSON.stringify(state));
	switch (action.type) {
		case TYPES.CART_ORDERALL:
			state.orderList = action.payload;
			break;
	}
	return state;
};