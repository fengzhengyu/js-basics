import * as TYPES from '../action-types';
import api from '../../api/index';
export default {
	loginSuccess(data) {
		return {
			type: TYPES.PERSONAL_LOGIN_SUCCESS,
			payload: data
		};
	},
	syncLoginInfo() {
		return async dispatch => {
			let data = await api.personal.loginGET();
			if (parseInt(data.code) !== 0) {
				dispatch({
					type: TYPES.PERSONAL_LOGIN_INFO,
					isLogin: false
				});
				return;
			}
			data = await api.personal.info();
			if (parseInt(data.code) === 0) {
				dispatch({
					type: TYPES.PERSONAL_LOGIN_INFO,
					isLogin: true,
					baseInfo: data.data
				});
			}
		};
	},
	resetBaseInfo() {
		return {
			type: TYPES.PERSONAL_LOGIN_INFO,
			isLogin: false,
			baseInfo: null
		};
	}
};