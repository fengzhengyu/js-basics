import * as TYPES from '../action-types';
import api from '../../api/index';
export default {
	syncOrderList() {
		return async dispatch => {
			let data = await api.cart.list();
			if (parseInt(data.code) === 0) {
				dispatch({
					type: TYPES.CART_ORDERALL,
					payload: data.data
				});
			}
		};
	}
};