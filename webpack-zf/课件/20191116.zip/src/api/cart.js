import axios from './axios';
const suffix = '/cart';
export default {
	list(state = 0) {
		return axios.get(`${suffix}/list`, {
			params: {
				state
			}
		});
	}
};