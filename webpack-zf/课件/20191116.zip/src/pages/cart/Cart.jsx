import React from 'react';
import { Link } from 'react-router-dom';
import './Cart.less';
import Recomend from './Recoment';
import Computed from './Computed';
import HeaderNav from '../../components/HeaderNav';
export default function Cart(props) {
	return <section className="cartBox">
		<HeaderNav title="购物车">
			<span>编辑</span>
		</HeaderNav>

		<div className="noTip">
			<i></i>
			购物车该没有信息哦，先去逛逛吧~
		</div>

		<div className="list">
			<Link to='/detail/xxx' className="clearfix">
				<i className="check active"></i>
				<div className="pic">
					<img src="https://img.youpin.mi-img.com/shopmain/3792969053dfccb7757c9ec0f06893ce.png?w=800&h=800" alt="" />
				</div>
				<div className="desc">
					<p>贵州茅台飞天酒酱香型白酒43度500ml*6整箱装</p>
					<p>￥5994.00</p>
				</div>
				<div className="count">
					<i className="minus disable"></i>
					<input type="number" value={4} onChange={ev => { }} />
					<i className="plus"></i>
				</div>
			</Link>
		</div>

		<Recomend />

		<Computed checked={true} />
	</section>;
}