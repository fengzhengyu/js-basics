import React from 'react';
export default function Pay(props) {
	return <>
		支付页面
	</>;
}