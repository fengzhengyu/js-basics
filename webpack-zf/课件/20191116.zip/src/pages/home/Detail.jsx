import React from 'react';
export default function Detail(props) {
	return <>
		产品详情
	</>;
}