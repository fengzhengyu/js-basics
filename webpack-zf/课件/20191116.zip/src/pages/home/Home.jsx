import React from 'react';
export default function Home(props) {
	return <>
		首页
	</>;
}